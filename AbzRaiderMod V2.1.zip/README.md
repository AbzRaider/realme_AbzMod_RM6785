# RyuXmod #AbzMod
Module Magisk For Realme G90/G90T/G95 Series

Feature :

    -Optimize Perf
    -Optimize Touch
    -Wifi Enhance Mod By Sarthak 
    - Include Props Realme GT Neo
